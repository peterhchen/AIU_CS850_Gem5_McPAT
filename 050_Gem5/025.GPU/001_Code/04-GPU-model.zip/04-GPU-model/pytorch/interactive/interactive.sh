bash --norc
