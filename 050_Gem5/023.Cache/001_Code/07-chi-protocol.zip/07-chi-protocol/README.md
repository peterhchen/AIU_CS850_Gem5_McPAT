# CHI protocol exercises

