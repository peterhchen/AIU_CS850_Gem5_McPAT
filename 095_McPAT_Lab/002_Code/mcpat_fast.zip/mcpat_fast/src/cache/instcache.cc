#include "instcache.h"

#include <iostream>
#include <string>

InstCache::InstCache(){};

InstCache::~InstCache(){};
