#include "datacache.h"

#include <iostream>
#include <string>

DataCache::DataCache(){};

DataCache::~DataCache(){};
